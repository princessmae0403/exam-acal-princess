
<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "notes_manager";

// Connect to MySQL
$conn = new mysqli(
    $servername,
    $username,
    $password,
    $database
);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

?>
