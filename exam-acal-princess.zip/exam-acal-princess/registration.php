<?php 
include 'db.php';

$message= '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$first= trim($_POST ['first_name']);
	$middle= trim($_POST ['middle_name']);
	$last= trim($_POST ['last_name']);
	$email= trim($_POST ['email']);
	$address= trim($_POST ['address']);
	$phone= trim($_POST ['phone_number']);
	$password= trim($_POST ['password']);
}
$sql = "INSERT INTO users (first_name,middle_name,last_name,email,address,phone_number,password) VALUES (?,?,?,?,?,?,?)";
$stmt = $pdo->prepare($sql);

$stmt->execute([
$first,
$middle,
$last,
$email,
$address,
$phone,
$password
]);

header ("Location : login.php?registered=1");
exit;
?>

<DOCTYPE html>
<html>
<head>
	<title> Registration </title>
</head>

<body>
<h2> User Registration </h2>

<form method="POST">
First Name:
<input type ='text' name='first_name'>
Middle Name:
<input type ='text' name='middle_name'>
Last Name:
<input type='text' name='last_name'>
Email:
<input type='email' name='email'>
Address:
<input type='text' name='address'>
Phone Number:
<input type = 'text' name='phone_number'>
Password:
<input type = 'password' name='password'>

<button type='submit'> Register </button>

</form>

<p>
	Already have an account?
	<a href='login.php'> Login </a>
</p>

</body>
</html> 


